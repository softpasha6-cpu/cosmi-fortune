# Cosmic Fortune — mockup assets

Эти изображения — нарезанные экраны утверждённого макета. Положите файлы JPG в папку `assets/screens/` репозитория `softpasha6-cpu/cosmi-fortune`.

Имена файлов:
- home.jpg
- games.jpg
- mines.jpg
- crash.jpg
- wheel.jpg
- dice.jpg
- profile.jpg
- bonuses.jpg

Следующий шаг интеграции: показать нужный экран как изображение на всю рабочую область и расположить прозрачные интерактивные зоны поверх него. Не растягивать изображения отдельно от пропорций экрана.
